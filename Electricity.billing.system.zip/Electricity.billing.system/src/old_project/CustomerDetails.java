package old_project;
// V-03 Single Responsibility Violation Class does too much: managing database, table population, UI, and error handling.
import java.awt.*;
import javax.swing.*;
import java.sql.*;
import net.proteanit.sql.DbUtils;
import java.awt.event.*;

// V-01 Large Class (Entire CustomerDetails class)
// The class handles UI creation, database interaction, and error handling all in one.
public class CustomerDetails extends JFrame implements ActionListener {

    Choice meternumber, cmonth;
    JTable table;
    JButton search, print;

    // V-02 (CustomerDetails() and fetchCustomerData())
    // These methods are tightly coupled to database logic but reside in the UI class.
    CustomerDetails() {
        super("Customer Details");

        // Setting up JFrame for UI
        setSize(1200, 650);
        setLocation(200, 150);

        table = new JTable(); // JTable for displaying data

        try {
            // V-02: Direct database call inside UI class (Tightly coupled with business logic)
            // This violates separation of concerns as the UI class is responsible for both the UI and fetching data.
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("select * from customer");

            // Displaying the fetched data in the JTable
            table.setModel(DbUtils.resultSetToTableModel(rs));  // Setting data to JTable using DbUtils
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Adding the table to JScrollPane for better visibility
        JScrollPane sp = new JScrollPane(table);
        add(sp);

        // Print button for printing the table data
        print = new JButton("Print");
        print.addActionListener(this);
        add(print, "South");

        // Making the frame visible
        setVisible(true);
    }

    // Action event handling for the print button
    @Override
    public void actionPerformed(ActionEvent ae) {
        try {
            // Printing the JTable contents
            table.print();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Main method to run the CustomerDetails frame
    public static void main(String[] args) {
        new CustomerDetails();
    }
}
