package old_project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Conn {
    Connection c;
    Statement s;

    public Conn() {
        try {
            // Establish database connection
            c = DriverManager.getConnection("jdbc:mysql://localhost:3306/ebs", "root", "pas41801");
            s = c.createStatement();

            // Log the connected database
            System.out.println("Connected to database: " + c.getCatalog());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}



