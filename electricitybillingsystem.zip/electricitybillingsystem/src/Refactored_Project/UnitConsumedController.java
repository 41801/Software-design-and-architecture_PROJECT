/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Refactored_Project;

/**
 *
 * @author a
 */

//PROPOSED FEATURE
import java.sql.*;

public class UnitConsumedController {

    // Method to fetch bill details from the database
    public static ResultSet getBillDetails(String meter) {
        try {
            Conn c = new Conn();
            String query = "SELECT * FROM bill WHERE meter_no = '" + meter + "'";
            return c.s.executeQuery(query);
        } catch (SQLException e) {
            return null;
        }
    }
      public void updateBill(String meter, String month, String units, int totalBill) {
        String query = "insert into bill values(?, ?, ?, ?, 'Not Paid')";
        try (Conn c = new Conn(); 
                PreparedStatement ps = c.prepareStatement(query)) {
            ps.setString(1, meter);
            ps.setString(2, month);
            ps.setString(3, units);
            ps.setInt(4, totalBill);
            ps.executeUpdate();
        } catch (Exception e) {
        }
    }

}

