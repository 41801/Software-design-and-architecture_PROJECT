package Refactored_Project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
//PROPOSED FEATURE
public class CustomerBilCalculatorUi extends JFrame {

    private final JLabel lblUsage;
    private final JLabel lblRate;
    private final JLabel lblTotal;
    private final JLabel lblStatus;
    private final JLabel lblInstructions;
    private JLabel lblEnergyTips;
    private JTextField txtUsage;
    private JComboBox<String> cmbTimeOfDay;
    private final JButton btnCalculate;
    private CustomerBillCalculatorController controller;

    public CustomerBilCalculatorUi() {
        // Set window properties
        setTitle("Electricity Billing System");
        setSize(400, 500);
        setLocationRelativeTo(null); // Center the window

        controller = new CustomerBillCalculatorController();

        // Set the layout manager for the frame
        setLayout(new BorderLayout(10, 10));

        // Create a main container panel
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new GridBagLayout()); // Using GridBagLayout for control
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Adding padding around the components

        // Panel for Instructions (Top Section)
        lblInstructions = new JLabel("<html><body>"
            + "<h3>Electricity Billing System Instructions:</h3>"
            + "<ul>"
            + "<li><b>Peak Hours:</b> 6 PM to 10 PM (Higher Rate)</li>"
            + "<li><b>Off-Peak Hours:</b> 10 PM to 6 AM (Lower Rate)</li>"
            + "<li><b>kWh:</b> Kilowatt-Hour, which measures electricity consumption.</li>"
            + "<li>Your bill is calculated based on usage in kWh and the time of day (Peak or Off-Peak).</li>"
            + "</ul>"
            + "</body></html>");
        lblInstructions.setFont(new Font("Arial", Font.PLAIN, 12));

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2; // Span across two columns
        gbc.anchor = GridBagConstraints.CENTER;
        mainPanel.add(lblInstructions, gbc);

        // Panel for Input Fields (Middle Section)
        lblUsage = new JLabel("Enter Usage (kWh): ");
        lblRate = new JLabel("Rate: ");
        lblTotal = new JLabel("Total: ");
        lblStatus = new JLabel();
        lblEnergyTips = new JLabel("<html><body><h3>Energy Saving Tips:</h3><pre> </pre></body></html>");
        
        txtUsage = new JTextField(10); // Set width for text field
        cmbTimeOfDay = new JComboBox<>(new String[] {"Peak", "Off-Peak"});

        // Adding components to the input panel with GridBagConstraints for proper alignment
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.EAST;
        mainPanel.add(lblUsage, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.WEST;
        mainPanel.add(txtUsage, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.EAST;
        mainPanel.add(new JLabel("Select Time of Day: "), gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.WEST;
        mainPanel.add(cmbTimeOfDay, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.EAST;
        mainPanel.add(lblRate, gbc);

        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.WEST;
        mainPanel.add(new JLabel(""), gbc); // Empty label for rate value placeholder

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.EAST;
        mainPanel.add(lblTotal, gbc);

        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.WEST;
        mainPanel.add(new JLabel(""), gbc); // Empty label for total value placeholder

        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2; // Make the Energy Tips label span across both columns
        gbc.anchor = GridBagConstraints.CENTER;
        mainPanel.add(lblEnergyTips, gbc);

        // Add the input panel to the center of the window
        add(mainPanel, BorderLayout.CENTER);

        // Panel for Buttons and Status (Bottom Section)
        JPanel buttonPanel = new JPanel();
        
        // Calculate Button
        btnCalculate = new JButton("Calculate Bill");
        btnCalculate.setBackground(new Color(34, 139, 34));
        btnCalculate.setForeground(Color.BLACK);
        btnCalculate.setFont(new Font("Arial", Font.BOLD, 14));
        
        // Status label
        lblStatus.setFont(new Font("Arial", Font.ITALIC, 12));
        
        // Adding the button and status label to the button panel
        buttonPanel.add(btnCalculate);
        buttonPanel.add(lblStatus);
        
        // Add the button panel to the bottom of the window
        add(buttonPanel, BorderLayout.SOUTH);

        // Button ActionListener
        btnCalculate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.calculateBill(txtUsage, cmbTimeOfDay, lblRate, lblTotal, lblStatus, lblEnergyTips);
            }
        });
    }

    public static void main(String[] args) {
        // Set Look and Feel
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException | UnsupportedLookAndFeelException e) {
        }
        
        // Creating and displaying the frame
        SwingUtilities.invokeLater(() -> {
            CustomerBilCalculatorUi frame = new CustomerBilCalculatorUi();
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setVisible(true);
        });
    }
}


