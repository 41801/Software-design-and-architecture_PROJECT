/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Refactored_Project;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
//R-01 Decoupled responsibilities into MeterInfo (UI) and MeterInfoController (logic).
public class MeterInfo extends JFrame implements ActionListener {

    Choice meterlocation, metertype, phasecode, billtype;
    JButton submit;
    String meternumber;

    public MeterInfo(String meternumber) {
        this.meternumber = meternumber;

        // Frame setup
        setSize(700, 500);
        setLocation(400, 200);
        setLayout(new BorderLayout());

        // Panel setup
        JPanel panel = createFormPanel();
        add(panel, "Center");

        // Side image
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/hicon1.jpg"));
        Image i2 = i1.getImage().getScaledInstance(150, 300, Image.SCALE_DEFAULT);
        JLabel image = new JLabel(new ImageIcon(i2));
        add(image, "West");

        // Frame background
        getContentPane().setBackground(Color.WHITE);
        setVisible(true);
    }

    private JPanel createFormPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(173, 216, 230));

        // Heading
        JLabel heading = createLabel("Meter Information", 180, 10, 200, 25, new Font("Tahoma", Font.PLAIN, 24));
        panel.add(heading);

        // Form labels and inputs
        panel.add(createLabel("Meter Number", 100, 80, 100, 20, null));
        JLabel lblMeterNumber = createLabel(meternumber, 240, 80, 200, 20, null);
        panel.add(lblMeterNumber);

        panel.add(createLabel("Meter Location", 100, 120, 100, 20, null));
        meterlocation = createChoice(new String[] { "Outside", "Inside" }, 240, 120, 200, 20);
        panel.add(meterlocation);

        panel.add(createLabel("Meter Type", 100, 160, 100, 20, null));
        metertype = createChoice(new String[] { "Electric Meter", "Solar Meter", "Smart Meter" }, 240, 160, 200, 20);
        panel.add(metertype);

        panel.add(createLabel("Phase Code", 100, 200, 100, 20, null));
        phasecode = createChoice(new String[] { "011", "022", "033", "044", "055", "066", "077", "088", "099" }, 240, 200, 200, 20);
        panel.add(phasecode);

        panel.add(createLabel("Bill Type", 100, 240, 100, 20, null));
        billtype = createChoice(new String[] { "Normal", "Industrial" }, 240, 240, 200, 20);
        panel.add(billtype);

        panel.add(createLabel("Days", 100, 280, 100, 20, null));
        JLabel lblDays = createLabel("30 Days", 240, 280, 200, 20, null);
        panel.add(lblDays);

        panel.add(createLabel("Note", 100, 320, 100, 20, null));
        JLabel lblNote = createLabel("By default, bill is calculated for 30 days only.", 240, 320, 400, 20, null);
        panel.add(lblNote);

        // Submit button
        submit = createButton("Submit", 220, 390, 100, 25);
        panel.add(submit);

        return panel;
    }
//R-12 Delegated database operations to MeterInfoController and added helper methods for clean navigation.
   // (e:g helper method dobuttons navigations)
    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == submit) {
            String location = meterlocation.getSelectedItem();
            String type = metertype.getSelectedItem();
            String code = phasecode.getSelectedItem();
            String billType = billtype.getSelectedItem();

            if (MeterInfoController.addMeterInfo(meternumber, location, type, code, billType, "30")) {
                JOptionPane.showMessageDialog(this, "Meter Information Added Successfully");
                setVisible(false);
            } else {
                JOptionPane.showMessageDialog(this, "Error Adding Meter Information");
            }
        }
    }

    private JLabel createLabel(String text, int x, int y, int width, int height, Font font) {
        JLabel label = new JLabel(text);
        label.setBounds(x, y, width, height);
        if (font != null) label.setFont(font);
        return label;
    }

    private Choice createChoice(String[] items, int x, int y, int width, int height) {
        Choice choice = new Choice();
        for (String item : items) {
            choice.add(item);
        }
        choice.setBounds(x, y, width, height);
        return choice;
    }

    private JButton createButton(String text, int x, int y, int width, int height) {
        JButton button = new JButton(text);
        button.setBounds(x, y, width, height);
        button.setBackground(Color.WHITE);
        button.setForeground(Color.BLACK);
        button.addActionListener(this);
        return button;
    }

    public static void main(String[] args) {
        new MeterInfo("723979");
    }
}
