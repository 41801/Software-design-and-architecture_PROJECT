/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Refactored_Project;

/**
 *
 * @author a
 */

//PROPOSED FEATURE
import java.awt.Color;
import javax.swing.*;

public class CustomerBillCalculatorController {

    // Method to calculate bill based on usage and time of day
    public void calculateBill(JTextField txtUsage, JComboBox<String> cmbTimeOfDay, JLabel lblRate, JLabel lblTotal, JLabel lblStatus, JLabel lblEnergyTips) {
        try {
            double usage = Double.parseDouble(txtUsage.getText());
            String timeOfDay = (String) cmbTimeOfDay.getSelectedItem();
            double rate = 0.0;
            double totalAmount = 0.0;
            if (timeOfDay.equals("Peak")) {
                rate = 1.5; 
            } else {
                rate = 1.0; 
            }
            // Consumption-Based Pricing
            if (usage > 200) {
                totalAmount = (200 * rate) + ((usage - 200) * (rate + 0.5)); 
            } else {
                totalAmount = usage * rate;
            }

            // Display the rate and total
            lblRate.setText("Rate: " + rate + " per kWh");
            lblTotal.setText("Total: " + totalAmount);
            lblStatus.setText("Billing Calculation Successful");
            lblStatus.setForeground(Color.GREEN);
             // Provide energy-saving tips based on usage and time of day
            provideEnergySavingTips(usage, timeOfDay, lblEnergyTips);
        } catch (NumberFormatException ex) {
            lblStatus.setText("Please enter valid usage");
            lblStatus.setForeground(Color.RED);
        }
    }

    // Method to provide energy-saving recommendations based on consumption and time of day
    private void provideEnergySavingTips(double usage, String timeOfDay, JLabel lblEnergyTips) {
        String tips = "";

        if (usage > 200) {
            tips += "- Consider shifting energy-intensive activities to off-peak hours (10 PM - 6 AM).\n";
            tips += "- Upgrade to energy-efficient appliances to reduce overall consumption.\n";
        }
        
        if (timeOfDay.equals("Peak")) {
            tips += "- Try to reduce usage during peak hours (6 PM - 10 PM) to save on high rates.\n";
        }

        if (usage < 100) {
            tips += "- You are using less energy! Keep maintaining efficient habits like turning off lights when not in use.\n";
        }

        // Display tips in the Energy Tips section
        lblEnergyTips.setText("<html><body><h3>Energy Saving Tips:</h3><pre>" + tips + "</pre></body></html>");
    }
}

