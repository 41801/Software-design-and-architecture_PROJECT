/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Refactored_Project;

import java.sql.SQLException;


//R-01 Extracted database logic into MeterInfoController.
public class MeterInfoController {
   //R-3 Delegated database-related tasks to MeterInfoController
    public static boolean addMeterInfo(String meterNumber, String location, String type, String phaseCode, String billType, String days) {

        String query = "INSERT INTO meter_info VALUES('" + meterNumber + "', '" + location + "', '" + type + "', '" + phaseCode + "', '" + billType + "', '" + days + "')";
        try {
            Conn conn = new Conn();
            conn.s.executeUpdate(query);
            return true;
        } catch (SQLException e) {
            return false;
        }
    }
}

