package Refactored_Project;

import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author a
 */
// R-04: Introduced CalculateBillController as an intermediary, reducing coupling and making the UI independent of DB implementation details.
public class CalculateBillController {
    private CalculateBillView view;
    private UnitConsumed model;

    // R-02: Delegated all database operations to CalculateBillController. The CalculateBillView class now solely focuses on the UI.
    public CalculateBillController(CalculateBillView view, UnitConsumed model) {
        this.view = view;
        this.model = model;

        // Populate meter numbers in the dropdown
        List<String> meterNumbers = model.getMeterNumbers();
        if (meterNumbers != null && !meterNumbers.isEmpty()) {
            for (String meter : meterNumbers) {
                if (meter != null && !meter.isEmpty()) { 
                    view.meternumber.add(meter);
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "No meter numbers found in the database.");
        }

        // Add event listeners
        view.meternumber.addItemListener(e -> updateCustomerInfo());
        view.next.addActionListener(e -> submitBill());
        view.cancel.addActionListener(e -> cancel());
    }

    private void updateCustomerInfo() {
        String meter = (String) view.meternumber.getSelectedItem();
        // Fetch customer info based on selected meter number
        String[] customerInfo = model.getCustomerInfo(meter);
        // If customer info is available, update the name and address in the UI
        if (customerInfo != null) {
            view.lblname.setText(customerInfo[0]);  // Name of the customer
            view.labeladdress.setText(customerInfo[1]);  // Address of the customer
        } else {
            view.lblname.setText("Name not found");
            view.labeladdress.setText("Address not found");
        }
    }

    private void submitBill() {
        try {
            String meter = (String) view.meternumber.getSelectedItem();
            int units = Integer.parseInt(view.tfunits.getText());
            String month = (String) view.cmonth.getSelectedItem();
            int totalBill = model.calculateBill(units);

            model.updateBill(meter, month, String.valueOf(units), totalBill);
            JOptionPane.showMessageDialog(null, "Customer Bill Updated Successfully");
            System.exit(0);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid input for units consumed!");
        }
    }

    private void cancel() {
        System.exit(0);
    }
}


