/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Refactored_Project;

/**
 *
 * @author a
 */


import javax.swing.JOptionPane;
import java.sql.*;
//R-01 The controller should handle database interactions.
public class SignupController {
    public void createAccount(String atype, String susername, String sname, String spassword, String smeter) {
        try (Conn c = new Conn()) {
            String query;
            //R-4 to avoid these problems use prepared statements aur parameterized queries
            PreparedStatement ps;
//R-2 (Inappropriate Intimacy)Use a controller: Move database interaction to a controller class.
            if (atype.equals("Admin")) {
                // Insert Admin record
                //Query placeholders (?) define
                query = "INSERT INTO login (username, name, password, user) VALUES (?, ?, ?, ?)";
                ps = c.getConnection().prepareStatement(query);
                ps.setString(1, susername);
                ps.setString(2, sname);
                ps.setString(3, spassword);
                ps.setString(4, atype);
            } else {
                // Check if customer exists by meter_no
                //parameters replaced with query
                query = "SELECT * FROM login WHERE meter_no = ?";
                ps = c.getConnection().prepareStatement(query);
                ps.setString(1, smeter);
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    // Update existing Customer
                    query = "UPDATE login SET username = ?, password = ?, user = ? WHERE meter_no = ?";
                    ps = c.getConnection().prepareStatement(query);
                    ps.setString(1, susername);
                    ps.setString(2, spassword);
                    ps.setString(3, atype);
                    ps.setString(4, smeter);
                } else {
                    // Insert new Customer
                    query = "INSERT INTO login (meter_no, username, name, password, user) VALUES (?, ?, ?, ?, ?)";
                    ps = c.getConnection().prepareStatement(query);
                    ps.setString(1, smeter);
                    ps.setString(2, susername);
                    ps.setString(3, sname);
                    ps.setString(4, spassword);
                    ps.setString(5, atype);
                }
            }

            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Account Created Successfully");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error Creating Account: " + e.getMessage());
        }
    }
}


