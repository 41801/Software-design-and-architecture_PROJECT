package Refactored_Project;


import java.sql.*;
//R-01 MERGE BOTH MANAGEVIEWINFORMATION AND 
//MANAGE UPDATEINFORMATION CLASSES DATABASE LOGIC
//NOT TO MAKE ANOTHER EXTRA CLASS THAT IS ALSO AN VOILATION 
//I MERGED BOTH CLASS DATABASE LOGIC
class ManageInformationController {
    private final String meter;

    public ManageInformationController(String meter) {
        this.meter = meter;
    }

    public String[] getCustomerDetails() {
        String[] details = new String[7];
        try {
            Conn c = new Conn(); // Assuming Conn is your database connection class
            ResultSet rs = c.s.executeQuery("select * from customer where meter_no = '" + meter + "'");
            if (rs.next()) {
                details[0] = rs.getString("name");
                details[1] = rs.getString("meter_no");
                details[2] = rs.getString("address");
                details[3] = rs.getString("city");
                details[4] = rs.getString("state");
                details[5] = rs.getString("email");
                details[6] = rs.getString("phone");
            }
        } catch (SQLException e) {
            // Handle exception properly
            
        }
        return details;
    }

    public void updateCustomerDetails(String address, String city, String state, String email, String phone) {
        try {
            Conn c = new Conn();  // Make sure Conn is properly defined
            c.s.executeUpdate("update customer set address = '" + address + "', city = '" + city + "', state = '" + state + "', email = '" + email + "', phone = '" + phone + "' where meter_no = '" + meter + "'");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public String getMeterNumber() {
        return meter;
    }
}


