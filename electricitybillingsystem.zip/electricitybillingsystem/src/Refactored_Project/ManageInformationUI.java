package Refactored_Project;

import javax.swing.*;
import java.awt.*;

// R-01: Controller Pattern Violation Resolved - Separated UI from business logic (ManageInformationController)

class ManageInformationUI extends JFrame {
    private JTextField tfaddress, tfstate, tfcity, tfemail, tfphone;
    private JButton update, cancel, view;
    private JLabel name, meternumber;
    private ManageInformationController controller;

    public ManageInformationUI(String meter) {
        controller = new ManageInformationController(meter); // Passed meter to controller for business logic

        setBounds(350, 150, 850, 650);
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        JLabel heading = new JLabel("UPDATE CUSTOMER INFORMATION");
        heading.setBounds(250, 0, 500, 40);
        heading.setFont(new Font("Tahoma", Font.PLAIN, 20));
        add(heading);

        // Customer Information Labels
        createUIComponents();
        addUIComponents();

        // View button functionality - open ViewInformation UI in a new window
        view.addActionListener(e -> {
            new ManageViewInformation(controller.getMeterNumber());
        });

        // Update button functionality
        update.addActionListener(e -> {
            String[] updatedDetails = getUpdatedDetails();
            controller.updateCustomerDetails(updatedDetails[0], updatedDetails[1], updatedDetails[2], updatedDetails[3], updatedDetails[4]);
            JOptionPane.showMessageDialog(this, "User Information Updated Successfully");
            dispose();
        });

        // Cancel button functionality
        cancel.addActionListener(e -> dispose());

        // Fetch and display initial customer details in the form
        String[] details = controller.getCustomerDetails();
        setCustomerDetails(details);
        
        setVisible(true);
    }

    // R-12: Long Method Resolved - Breaking down the method into smaller helper methods
    private void createUIComponents() {
        JLabel lblname = new JLabel("Name");
        lblname.setBounds(70, 80, 100, 20);
        name = new JLabel("");
        name.setBounds(250, 80, 100, 20);

        JLabel lblmeternumber = new JLabel("Meter Number");
        lblmeternumber.setBounds(70, 140, 100, 20);
        meternumber = new JLabel("");
        meternumber.setBounds(250, 140, 100, 20);

        JLabel lbladdress = new JLabel("Address");
        lbladdress.setBounds(70, 200, 100, 20);
        tfaddress = new JTextField();
        tfaddress.setBounds(250, 200, 200, 20);

        JLabel lblcity = new JLabel("City");
        lblcity.setBounds(70, 260, 100, 20);
        tfcity = new JTextField();
        tfcity.setBounds(250, 260, 200, 20);

        JLabel lblstate = new JLabel("State");
        lblstate.setBounds(500, 80, 100, 20);
        tfstate = new JTextField();
        tfstate.setBounds(650, 80, 200, 20);

        JLabel lblemail = new JLabel("Email");
        lblemail.setBounds(500, 140, 100, 20);
        tfemail = new JTextField();
        tfemail.setBounds(650, 140, 200, 20);

        JLabel lblphone = new JLabel("Phone");
        lblphone.setBounds(500, 200, 100, 20);
        tfphone = new JTextField();
        tfphone.setBounds(650, 200, 200, 20);
    }

    // R-12: Long Method Resolved - Breaking down the method into smaller helper methods
    private void addUIComponents() {
        update = new JButton("Update");
        update.setBackground(Color.WHITE);
        update.setForeground(Color.BLACK);
        update.setBounds(70, 300, 100, 25);

        cancel = new JButton("Cancel");
        cancel.setBackground(Color.WHITE);
        cancel.setForeground(Color.BLACK);
        cancel.setBounds(230, 300, 100, 25);

        view = new JButton("View");
        view.setBackground(Color.WHITE);
        view.setForeground(Color.BLACK);
        view.setBounds(400, 300, 100, 25);

        // Add components to frame
        add(update);
        add(cancel);
        add(view);
    }

    // R-03: Long Class Violation Resolved - The UI and business logic have been separated

    // Method to set the customer details into the form fields
    private void setCustomerDetails(String[] details) {
        name.setText(details[0]);
        meternumber.setText(details[1]);
        tfaddress.setText(details[2]);
        tfcity.setText(details[3]);
        tfstate.setText(details[4]);
        tfemail.setText(details[5]);
        tfphone.setText(details[6]);
    }

    // Method to fetch updated details from the form fields
    private String[] getUpdatedDetails() {
        return new String[]{tfaddress.getText(), tfcity.getText(), tfstate.getText(), tfemail.getText(), tfphone.getText()};
    }

    public static void main(String[] args) {
        new ManageInformationUI("723979");  // Replace with an actual meter number
    }
}

