/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Refactored_Project;

/**
 *
 * @author a
 */

//PROPOSED FEATURE NO NEED TO REFACTOR ALREDAY UI AND DB SEPRATE 
import javax.swing.table.DefaultTableModel;
import java.sql.*;

public class AdminResolveQueryController {

    // Fetch complaints from the database
    public DefaultTableModel getComplaints() {
        String sql = "SELECT id, customer_name, customer_meter, query_text, status FROM customer_queries";
        try (Conn conn = new Conn();
             Connection connection = conn.getConnection();
             Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            String[] columns = {"ID", "Customer Name", "Meter Number", "Complaint", "Status"};
            DefaultTableModel tableModel = new DefaultTableModel(columns, 0);

            while (rs.next()) {
                tableModel.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("customer_name"),
                        rs.getString("customer_meter"),
                        rs.getString("query_text"),
                        rs.getString("status")
                });
            }
            return tableModel;

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    // Update complaint status in the database
    public boolean updateComplaintStatus(int complaintId, String status) {
        String updateQuery = "UPDATE customer_queries SET status = ? WHERE id = ?";
        try (Conn conn = new Conn();
             Connection connection = conn.getConnection();
             PreparedStatement pst = connection.prepareStatement(updateQuery)) {

            pst.setString(1, status);
            pst.setInt(2, complaintId);

            return pst.executeUpdate() > 0; // Return true if update is successful
        } catch (SQLException e) {
            return false;
        }
    }
}

