package Refactored_Project;

import java.awt.*;
import javax.swing.*;
import java.sql.*;
import net.proteanit.sql.DbUtils;
//R-3 Long Class(A class has too many responsibilities or too much code,
//making it difficult to manage and understand.)
public class DepositDetails extends JFrame {

    Choice meternumber, cmonth;
    JTable table;
    JButton search;

    private final DepositController DepositController;

    public DepositDetails(String string) {
        super("Deposit Details");

        DepositController = new DepositController();

        setSize(700, 700);
        setLocation(400, 100);

        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        JLabel lblmeternumber = new JLabel("Search By Meter Number");
        lblmeternumber.setBounds(20, 20, 150, 20);
        add(lblmeternumber);

        meternumber = new Choice();
        meternumber.setBounds(180, 20, 150, 20);
        add(meternumber);

        
        loadMeterNumbers();

        JLabel lblmonth = new JLabel("Search By Month");
        lblmonth.setBounds(400, 20, 100, 20);
        add(lblmonth);

        cmonth = new Choice();
        cmonth.setBounds(520, 20, 150, 20);
        addMonthChoices();
        add(cmonth);

        table = new JTable();
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(0, 100, 700, 600);
        add(sp);

        search = new JButton("Search");
        search.setBounds(20, 70, 80, 20);
        search.addActionListener(e -> searchData());
        add(search);

        setVisible(true);
    }

    // R-2: Helper method to load meter numbers from the database)**: Calls the controller for fetching meter numbers.
    private void loadMeterNumbers() {
        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("SELECT meter_no FROM customer");
            boolean found = false;
            while (rs.next()) {
                String meterNo = rs.getString("meter_no");
                if (meterNo != null) {
                    meternumber.add(meterNo); // Add only non-null meter numbers
                    found = true;
                }
            }
            if (!found) {
                System.out.println("No meter numbers found in the database.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // R-2: Helper method to add month choices) Adds months to the Choice component.
    private void addMonthChoices() {
        String[] months = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
        for (String month : months) {
            cmonth.add(month);
        }
    }

    // R-2: Extracted database logic into a separate method in the controller)**: Now all database querying logic is in DepositController.
    private void searchData() {
        String query = "SELECT * FROM bill WHERE meter_no = '" + meternumber.getSelectedItem() + "' AND month = '" + cmonth.getSelectedItem() + "'";
        try {
            ResultSet rs = DepositController.getBills(query);
            if (rs != null) {
                table.setModel(DbUtils.resultSetToTableModel(rs));
            } else {
                System.out.println("No data found for the selected criteria.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new DepositDetails("457261");
    }
}







                

