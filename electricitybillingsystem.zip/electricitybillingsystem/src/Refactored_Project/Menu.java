package Refactored_Project;

import javax.swing.*;
import java.awt.*;

public class Menu extends JFrame {

    Menu(String atype, String meter) {
        // Set window properties.
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/elect1.jpg"));
        JLabel image = new JLabel(new ImageIcon(i1.getImage().getScaledInstance(1550, 850, Image.SCALE_DEFAULT)));
        add(image);

        JMenuBar menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        // R-1 Initialize MenuController: Delegated menu creation to a dedicated controller class.
        MenuController menuController = new MenuController(this, atype, meter);

        // R-03 Role-based menu addition: Separates logic for Admin and User menus.
        if (atype.equals("Admin")) {
            menuBar.add(menuController.getMasterMenu());
        } else {
            menuBar.add(menuController.getInfoMenu());
            menuBar.add(menuController.getUserMenu());
            menuBar.add(menuController.getReportMenu());
        }

        menuBar.add(menuController.getComplaintsMenu());
        menuBar.add(menuController.getExitMenu());

        setLayout(new FlowLayout());
        setVisible(true);
    }
}