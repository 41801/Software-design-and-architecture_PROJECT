/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Refactored_Project;

/**
 *
 * @author a
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
 
//R-1 MAKE UI seprate class OF UI
public class Login extends JFrame implements ActionListener {
    private JButton login, cancel, signup;
    private JTextField username, password;
    private Choice roleChoice;

    // Constructor to set up the login screen
    public Login() {
        super("Login Page");
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        createUIComponents();
        setSize(640, 300);
        setLocation(400, 200);
        setVisible(true);
    }
    private void createUIComponents() {
        JLabel lblusername = new JLabel("Username");
        lblusername.setBounds(300, 20, 100, 20);
        add(lblusername);
        username = new JTextField();
        username.setBounds(400, 20, 150, 20);
        add(username);

        JLabel lblpassword = new JLabel("Password");
        lblpassword.setBounds(300, 60, 100, 20);
        add(lblpassword);

        password = new JTextField();
        password.setBounds(400, 60, 150, 20);
        add(password);

        JLabel loggininas = new JLabel("Logging in as");
        loggininas.setBounds(300, 100, 100, 20);
        add(loggininas);

        roleChoice = new Choice();
        roleChoice.add("Admin");
        roleChoice.add("Customer");
        roleChoice.setBounds(400, 100, 150, 20);
        add(roleChoice);
        login = new JButton("Login");
        login.setBounds(330, 160, 100, 20);
        login.addActionListener(this);
        add(login);

        cancel = new JButton("Cancel");
        cancel.setBounds(450, 160, 100, 20);
        cancel.addActionListener(this);
        add(cancel);

        signup = new JButton("Signup");
        signup.setBounds(380, 200, 100, 20);
        signup.addActionListener(this);
        add(signup);
        setImage();
    }
    private void setImage() {
        ImageIcon i7 = new ImageIcon(ClassLoader.getSystemResource("icon/second.jpg"));
        Image i8 = i7.getImage().getScaledInstance(250, 250, Image.SCALE_DEFAULT);
        JLabel image = new JLabel(new ImageIcon(i8));
        image.setBounds(0, 0, 250, 250);
        add(image);
    }
    //R-12 Break the actionPerformed method into smaller, meaningful methods. like make  login controller class seprate and also make if else statement in in actionPerformed method that shows 
//if username and password is valid then proceed to next screen otherwise show message(validate)
    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == login) {
            String susername = username.getText();
            String spassword = password.getText();
            String userRole = roleChoice.getSelectedItem();
            
            // Call the LoginController to authenticate the user
            boolean isValid = LoginController.authenticateUser(susername, spassword, userRole);

            if (isValid) {
                setVisible(false);
                //R-06 Now  Login class is not acting as a middleman between the user and the Menu class.
                //It directly creates an instance of the Menu class 
                //(new Menu(userRole, susername)) after authentication is validated by the LoginController.
                new Menu(userRole, susername);  // Proceed to the next screen
            } else {
                JOptionPane.showMessageDialog(null, "Invalid Login");
                username.setText("");
                password.setText("");
            }
        } else if (ae.getSource() == cancel) {
            setVisible(false);  
        } else if (ae.getSource() == signup) {
            setVisible(false);  
            new SignupUI();
        }
    }
}


