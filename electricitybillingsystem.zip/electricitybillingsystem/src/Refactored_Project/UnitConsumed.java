/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Refactored_Project;

/**
 *
 * @author a
 */
//PROPOSED FEATURE
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UnitConsumed {
   
  public String[] getCustomerInfo(String meter) {
        String[] customerInfo = new String[2];  // Assuming you want to return name and address
        String query = "SELECT name, address FROM customer WHERE meter_no = ?";
        
        try (Conn c = new Conn(); 
             PreparedStatement ps = c.getConnection().prepareStatement(query)) {
            
            ps.setString(1, meter);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                customerInfo[0] = rs.getString("name");
                customerInfo[1] = rs.getString("address");
            }
        } catch (SQLException e) {
      // Handle error appropriately (e.g., show a message dialog or log the error)
            
        } 
        return customerInfo;
    }

    public UnitConsumed(String meter) {
    }
    
//BillService class to encapsulate all tax
    public int calculateBill(int unitsConsumed) {
        int totalBill = 0;
        String query = "select * from tax";
        try (Conn c = new Conn(); ResultSet rs = c.s.executeQuery(query)) {
            while (rs.next()) {
                totalBill += unitsConsumed * Integer.parseInt(rs.getString("cost_per_unit"));
                totalBill += Integer.parseInt(rs.getString("meter_rent"));
                totalBill += Integer.parseInt(rs.getString("service_charge"));
                totalBill += Integer.parseInt(rs.getString("service_tax"));
                totalBill += Integer.parseInt(rs.getString("swacch_bharat_cess"));
                totalBill += Integer.parseInt(rs.getString("fixed_tax"));
            }
        } catch (Exception e) {
        }
        return totalBill;
    }

    public void updateBill(String meter, String month, String units, int totalBill) {
        String query = "insert into bill values(?, ?, ?, ?, 'Not Paid')";
        try (Conn c = new Conn(); 
                PreparedStatement ps = c.prepareStatement(query)) {
            ps.setString(1, meter);
            ps.setString(2, month);
            ps.setString(3, units);
            ps.setInt(4, totalBill);
            ps.executeUpdate();
        } catch (Exception e) {
        }
    }

  

  public List<String> getMeterNumbers() {
    List<String> meterNumbers = new ArrayList<>();
    String query = "SELECT meter_no FROM customer";
    try (Conn c = new Conn();
         Statement s = c.getConnection().createStatement();
         ResultSet rs = s.executeQuery(query)) {
        while (rs.next()) {
            String meter = rs.getString("meter_no");
            System.out.println("Fetched meter number: " + meter); 
            meterNumbers.add(meter);
        }
    } catch (Exception e) {
    }
    if (meterNumbers.isEmpty()) {
        System.out.println("No meter numbers found in the database.");
    }
    return meterNumbers;
}

     public static void main(String[] args) {
        String meter = null;
        UnitConsumed model = new UnitConsumed(meter);
        CalculateBillView view = new CalculateBillView();
      CalculateBillController calculateBillController = new CalculateBillController(view, model);
     }
    
}


