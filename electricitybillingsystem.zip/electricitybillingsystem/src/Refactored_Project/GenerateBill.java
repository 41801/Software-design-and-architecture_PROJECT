/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Refactored_Project;

//PROPOSED FEATURE

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class GenerateBill extends JFrame implements ActionListener {

    private final String meter;
    private final JButton billButton;
    private final Choice monthChoice;
    private final JTextArea area;
    private final GenerateBillController GenerateBillController; // Declare billController here

    GenerateBill(String meter) {
        this.meter = meter;
        this.GenerateBillController = new GenerateBillController(); // Initialize billController

        setSize(500, 800);
        setLocation(550, 30);
        setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        panel.add(new JLabel("Generate Bill"));
        panel.add(new JLabel(meter));

        monthChoice = new Choice();
        for (String month : new String[]{"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"})
            monthChoice.add(month);

        area = new JTextArea(50, 15);
        area.setText("\n\n\t--------Click on the---------\n\t Generate Bill Button to get\n\tthe bill of the Selected Month");
        area.setFont(new Font("Senserif", Font.ITALIC, 18));

        JScrollPane pane = new JScrollPane(area);
        billButton = new JButton("Generate Bill");
        billButton.addActionListener(this);

        add(panel, BorderLayout.NORTH);
        add(pane, BorderLayout.CENTER);
        add(billButton, BorderLayout.SOUTH);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        try {
            String month = monthChoice.getSelectedItem();
            area.setText("\tReliance Power Limited\nELECTRICITY BILL GENERATED FOR THE MONTH\n\tOF " + month + ", 2022\n\n\n");

            area.append(GenerateBillController.getCustomerDetails(meter));
            area.append("\n---------------------------------------------------\n");
            area.append(GenerateBillController.getMeterInfo(meter));
            area.append("\n---------------------------------------------------\n");
            area.append(GenerateBillController.getTaxDetails());
            area.append("\n");
            area.append(GenerateBillController.getBillDetails(meter, month));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new GenerateBill("934844");
    }
}



