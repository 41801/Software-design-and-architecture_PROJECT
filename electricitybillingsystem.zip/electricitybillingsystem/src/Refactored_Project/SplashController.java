/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Refactored_Project;

//R-1 Split responsibilities. Keep UI creation in the Splash VIEW and move thread-related logic into a separate controller class.
public class SplashController implements Runnable {
    private Thread t;
    private SplashView splash;
//R-3 Long Class(so solution is make public void startSplash() method)
    public void startSplash() {
        splash = new SplashView();  
        t = new Thread(this);
        t.start();
        resizeWindow(splash);  
    }
    //R-2(Inappropriate Intimacy) Move resizing and splash screen logic to a dedicated controller class to separate concerns and reduce the intimacy between UI and behavior.

    private void resizeWindow(SplashView splash) {
        int x = 1;
        for (int i = 2; i < 600; i += 4, x += 1) {
            splash.setSize(i + x, i);
            splash.setLocation(700 - ((i + x) / 2), 400 - (i / 2));
            try {
                Thread.sleep(5);
            } catch (InterruptedException e) {
            }
        }
    }

    @Override
    public void run() {
        try {
         
            Thread.sleep(5000);  
            splash.setVisible(false); 
           
            Login login = new Login(); 
        } catch (InterruptedException e) {
            //handle the exception that occurs if the thread is interrupted while sleeping or waiting.
        }
    }
}


