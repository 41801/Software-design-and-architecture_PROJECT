/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Refactored_Project;

/**
 *
 * @author a
 */


//PROPOSED FEATURE
import java.sql.*;

public class GenerateBillController {

    private Conn conn;

    public  GenerateBillController () {
        conn = new Conn();
    }

    public String getCustomerDetails(String meter) throws SQLException {
        ResultSet rs = conn.s.executeQuery("SELECT * FROM customer WHERE meter_no = '" + meter + "'");
        if (rs.next()) {
            return String.format("\n    Customer Name: %s\n    Meter Number: %s\n    Address: %s\n    City: %s\n    State: %s\n    Email: %s\n    Phone: %s",
                    rs.getString("name"), rs.getString("meter_no"), rs.getString("address"),
                    rs.getString("city"), rs.getString("state"), rs.getString("email"), rs.getString("phone"));
        }
        return "";
    }

    public String getMeterInfo(String meter) throws SQLException {
        ResultSet rs = conn.s.executeQuery("SELECT * FROM meter_info WHERE meter_no = '" + meter + "'");
        if (rs.next()) {
            return String.format("\n    Meter Location: %s\n    Meter Type: %s\n    Phase Code: %s\n    Bill Type: %s\n    Days: %s",
                    rs.getString("meter_location"), rs.getString("meter_type"), rs.getString("phase_code"),
                    rs.getString("bill_type"), rs.getString("days"));
        }
        return "";
    }

    public String getTaxDetails() throws SQLException {
        ResultSet rs = conn.s.executeQuery("SELECT * FROM tax");
        if (rs.next()) {
            return String.format("\n    Cost Per Unit: %s\n    Meter Rent: %s\n    Service Charge: %s\n    Service Tax: %s\n    Swacch Bharat Cess: %s\n    Fixed Tax: %s",
                    rs.getString("cost_per_unit"), rs.getString("cost_per_unit"), rs.getString("service_charge"),
                    rs.getString("service_charge"), rs.getString("swacch_bharat_cess"), rs.getString("fixed_tax"));
        }
        return "";
    }

    public String getBillDetails(String meter, String month) throws SQLException {
        ResultSet rs = conn.s.executeQuery("SELECT * FROM bill WHERE meter_no = '" + meter + "' AND month = '" + month + "'");
        if (rs.next()) {
            return String.format("\n    Current Month: %s\n    Units Consumed: %s\n    Total Charges: %s\n-------------------------------------------------------\n    Total Payable: %s",
                    rs.getString("month"), rs.getString("units"), rs.getString("totalbill"), rs.getString("totalbill"));
        }
        return "";
    }
}

