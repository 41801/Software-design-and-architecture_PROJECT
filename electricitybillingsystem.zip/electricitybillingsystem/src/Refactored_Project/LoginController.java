/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Refactored_Project;

/**
 *
 * @author a
 */
import java.sql.*;
//R-1 Move Controller (authentication) to a separate LoginController class.

public class LoginController {
//R-05(Duplicate Code) Move authenticationUser to a separate  Login Controller class.
    public static boolean authenticateUser(String username, String password, String user) {
        try (Conn c = new Conn()) {
            String query = "select * from login where username = ? and password = ? and user = ?";
            try (PreparedStatement ps = c.getConnection().prepareStatement(query)) {
                ps.setString(1, username);
                ps.setString(2, password);
                ps.setString(3, user);
                ResultSet rs = ps.executeQuery();

                return rs.next();
            }
        } catch (SQLException e) {
            return false;
        }
    }    public static void main(String[] args) {
        new Login();  // Start the Login screen
    }
}

