/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Refactored_Project;

/**
 *
 * @author a
 */

import java.sql.*;

// R-1: Split responsibilities into CustomerDetailsController for logic and CustomerDetailsUI for UI.
// R-03: Separate concerns into multiple classes (Controller, UI).
public class CustomerDetailsController {

    // R-1: Method to fetch customer data from the database
    
    public ResultSet fetchCustomerData() {
        ResultSet rs = null;
        try {
            Conn c = new Conn();  // Database connection
            rs = c.s.executeQuery("SELECT * FROM customer");  // Execute the query to fetch customer data
        } catch (SQLException e) {
            e.printStackTrace();  // R-03: Error handling in controller class
        }
        return rs;
    }
}


