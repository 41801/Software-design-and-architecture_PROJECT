package Refactored_Project;

import java.sql.*;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PayBillController {

    private final PayBillUI view;
    private final String meter;

    public PayBillController(PayBillUI view, String meter) {
        this.view = view;
        this.meter = meter;
    }

    public void start() {
        // Set listeners for buttons
        this.view.pay.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateBillStatus(); // R-1: Controller Pattern Violation - business logic inside the UI class
            }
        });

        this.view.back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                view.setVisible(false); // R-1: Controller Pattern Violation - mixing UI handling inside controller
            }
        });

        // Initial data load
        view.loadCustomerInfo(); // R-1: Controller Pattern Violation - direct UI logic in controller
        view.loadBillInfo("January"); // Default to January - direct UI manipulation in controller
    }

    private void updateBillStatus() {
        try (Conn c = new Conn()) {
            c.s.executeUpdate("UPDATE bill SET status = 'Paid' WHERE meter_no = '" + meter + "' AND month = '" + view.cmonth.getSelectedItem() + "'");
            view.labelstatus.setText("Payment successful!");
            view.labelstatus.setForeground(Color.GREEN);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}



