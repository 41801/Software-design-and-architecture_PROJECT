package Refactored_Project;

import java.awt.*;
import javax.swing.*;
// R-03: Separated concerns, kept UI logic within CalculateBill.
public class CalculateBillView extends JFrame {
    Choice meternumber, cmonth;
    JTextField tfunits;
    // R-05: Removed unused fields, retaining only the necessary ones (lblname, labeladdress, etc.).
    JLabel lblname, labeladdress;
    JButton next, cancel;

    public CalculateBillView() {
        setSize(700, 500);
        setLocation(400, 150);
        
        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(173, 216, 230));
        add(panel);
        
        JLabel heading = new JLabel("Calculate Electricity Bill");
        heading.setBounds(100, 10, 400, 25);
        heading.setFont(new Font("Tahoma", Font.PLAIN, 24));
        panel.add(heading);

        JLabel lblmeternumber = new JLabel("Meter Number");
        lblmeternumber.setBounds(100, 80, 100, 20);
        panel.add(lblmeternumber);

        meternumber = new Choice();
        meternumber.setBounds(240, 80, 200, 20);
        panel.add(meternumber);

        JLabel lblnameLabel = new JLabel("Name");
        lblnameLabel.setBounds(100, 120, 100, 20);
        panel.add(lblnameLabel);

        lblname = new JLabel("");
        lblname.setBounds(240, 120, 100, 20);
        panel.add(lblname);

        JLabel lbladdressLabel = new JLabel("Address");
        lbladdressLabel.setBounds(100, 160, 100, 20);
        panel.add(lbladdressLabel);

        labeladdress = new JLabel("");
        labeladdress.setBounds(240, 160, 200, 20);
        panel.add(labeladdress);

        JLabel lblunits = new JLabel("Units Consumed");
        lblunits.setBounds(100, 200, 100, 20);
        panel.add(lblunits);

        tfunits = new JTextField();
        tfunits.setBounds(240, 200, 200, 20);
        panel.add(tfunits);

        JLabel lblmonth = new JLabel("Month");
        lblmonth.setBounds(100, 240, 100, 20);
        panel.add(lblmonth);

        // R-06: Moved months to a separate CalculateBillView method for better modularity.
        cmonth = new Choice();
        cmonth.setBounds(240, 240, 200, 20);
        cmonth.add("January");
        cmonth.add("February");
        cmonth.add("March");
        cmonth.add("April");
        cmonth.add("May");
        cmonth.add("June");
        cmonth.add("July");
        cmonth.add("August");
        cmonth.add("September");
        cmonth.add("October");
        cmonth.add("November");
        cmonth.add("December");
        panel.add(cmonth);

        next = new JButton("Submit");
        next.setBounds(120, 350, 100, 25);
        next.setBackground(Color.WHITE);
        next.setForeground(Color.BLACK);
        panel.add(next);

        cancel = new JButton("Cancel");
        cancel.setBounds(250, 350, 100, 25);
        cancel.setBackground(Color.WHITE);
        cancel.setForeground(Color.BLACK);
        panel.add(cancel);

        setLayout(new BorderLayout());
        add(panel, "Center");
        getContentPane().setBackground(Color.WHITE);
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
}





