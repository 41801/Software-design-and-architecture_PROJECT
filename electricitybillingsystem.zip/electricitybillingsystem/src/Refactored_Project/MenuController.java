package Refactored_Project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

// R-1 Split into smaller classes: Created a dedicated MenuController class for handling menu actions.
// This addresses the violation where all menu logic was handled in a single, large class.
public class MenuController {
    JFrame frame;
    String atype, meter;

    public MenuController(JFrame frame, String atype, String meter) {
        this.frame = frame;
        this.atype = atype;
        this.meter = meter;
    }

    // R-2 Delegate actions to a controller (MenuController): 
    // This separates menu creation from the UI setup, adhering to the single responsibility principle.
    public JMenu getMasterMenu() {
        JMenu master = new JMenu("Master");
        master.setForeground(Color.BLUE);

        // Reused a helper method to create menu items.
        master.add(createMenuItem("New Customer", "icon/icon1.png", e -> new NewCustomer("")));
        master.add(createMenuItem("Customer Details", "icon/icon2.png", e -> new CustomerDetailsUI("")));
        master.add(createMenuItem("Deposit Details", "icon/icon3.png", e -> new DepositDetails("")));
        master.add(createMenuItem("Calculate Bill", "icon/icon5.png", e -> new UnitConsumed(meter)));

        return master;
    }

    public JMenu getInfoMenu() {
        JMenu info = new JMenu("Information");
        info.setForeground(Color.RED);

        // R-3 Temporary Field: Reused helper method to simplify item creation.
        info.add(createMenuItem("Manage Information", "icon/icon4.png", e -> ManageInformationUI(meter)));

        return info;
    }

    public JMenu getUserMenu() {
        JMenu user = new JMenu("User");
        user.setForeground(Color.BLUE);

        user.add(createMenuItem("Pay Bill", "icon/icon4.png", e -> new PayBillUI(meter)));
        user.add(createMenuItem("Bill Details", "icon/icon6.png", e -> new BillDetails(meter)));

        return user;
    }

    public JMenu getReportMenu() {
        JMenu report = new JMenu("Report");
        report.setForeground(Color.RED);

        report.add(createMenuItem("Generate Bill", "icon/icon7.png", e -> new GenerateBill(meter)));

        return report;
    }

    public JMenu getComplaintsMenu() {
        JMenu complaints;

        if (atype.equals("Admin")) {
            // Admin's "Query Panel" menu
            complaints = new JMenu("Query Panel");
            complaints.setForeground(Color.RED);

            complaints.add(createMenuItem("Resolve Query", "icon/icon9.png", e -> {
                AdminResolveQueryUI adminQuery = new AdminResolveQueryUI(meter);
                adminQuery.setVisible(true);
            }));
        } else {
            // Customer's "Complaints" menu
            complaints = new JMenu("Complaints");
            complaints.setForeground(Color.RED);

            complaints.add(createMenuItem("Customer Complaints", "icon/icon8.png", e -> {
                CustomerComplaints customerComplaints = new CustomerComplaints(meter);
                customerComplaints.setVisible(true);
            }));
        }

        return complaints;
    }

    public JMenu getExitMenu() {
        JMenu exitMenu = new JMenu("Exit");
        exitMenu.setForeground(Color.RED);

        // R-4 Removed and replaced with proper login-states.
        exitMenu.add(createMenuItem("Exit", "icon/icon11.png", e -> {
            frame.setVisible(false);
            new Login(); // Delegated login navigation logic.
        }));

        return exitMenu;
    }

    // R-3 Moved repetitive menu item creation logic to this reusable method, reducing redundancy.
    private JMenuItem createMenuItem(String name, String iconPath, ActionListener action) {
        JMenuItem item = new JMenuItem(name);
        item.setFont(new Font("monospaced", Font.PLAIN, 12));
        item.setBackground(Color.WHITE);

        ImageIcon icon = new ImageIcon(ClassLoader.getSystemResource(iconPath));
        item.setIcon(new ImageIcon(icon.getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT)));

        item.addActionListener(action);
        return item;
    }

    // Placeholder for ManageInformationUI method.
    private JMenuItem ManageInformationUI(String meter) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}

   

    
  

   

   

    



