/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Refactored_Project;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author a
 */


// Controller Class for handling Bill database interactions
class DepositController {

    public ResultSet getBills(String query) throws SQLException {
        Conn c = new Conn();
        return c.s.executeQuery(query);
    }
    
}
