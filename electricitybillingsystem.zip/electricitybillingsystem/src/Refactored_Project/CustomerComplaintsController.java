/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Refactored_Project;

import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Controller class for handling customer complaints submission
 */
//PROPOSED FEATURE

import java.sql.Connection;


public class CustomerComplaintsController {
    public boolean submitComplaint(String customerName, String meterNumber, String query) {
        String sql = "INSERT INTO customer_queries (customer_name, customer_meter, query_text, status) VALUES (?, ?, ?, 'Pending')";
        try (Conn conn = new Conn();
             Connection connection = conn.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setString(1, customerName);
            ps.setString(2, meterNumber);
            ps.setString(3, query);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            return false;
        }
    }
}



