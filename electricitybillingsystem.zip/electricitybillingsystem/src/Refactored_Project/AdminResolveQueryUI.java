/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Refactored_Project;

/**
 *
 * @author a
 */
//PROPOSED FEATURE 
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AdminResolveQueryUI extends JFrame {
    private final JTable queryTable;
    private final JButton loadButton;
    private final JButton resolveButton;
    private final JComboBox<String> statusComboBox;
    private final AdminResolveQueryController controller;

    public AdminResolveQueryUI(String meter) {
        // Initialize frame properties
        setTitle("Admin Resolve Query Panel");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Initialize buttons, combo box, and controller
        loadButton = new JButton("Load Customer Complaints");
        resolveButton = new JButton("Resolve Query");
        statusComboBox = new JComboBox<>(new String[]{"Select Status", "Resolved", "Pending", "Accepted", "Not Accepted"});
        controller = new AdminResolveQueryController();

        queryTable = new JTable();

        // Set the layout
        setLayout(new BorderLayout());

        // Add components to the frame
        JPanel topPanel = new JPanel();
        topPanel.add(loadButton);
        topPanel.add(statusComboBox);
        topPanel.add(resolveButton);

        add(topPanel, BorderLayout.NORTH);

        JScrollPane scrollPane = new JScrollPane(queryTable);
        add(scrollPane, BorderLayout.CENTER);

        // Button actions
        loadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadComplaints();
            }
        });

        resolveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                resolveQuery();
            }
        });
    }

    // Load complaints into the table
    private void loadComplaints() {
        DefaultTableModel model = controller.getComplaints();
        if (model != null) {
            queryTable.setModel(model);
        } else {
            JOptionPane.showMessageDialog(this, "Error loading complaints.", "Load Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Resolve a selected complaint
    private void resolveQuery() {
        int selectedRow = queryTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a complaint to resolve.", "No Complaint Selected", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int complaintId = (int) queryTable.getValueAt(selectedRow, 0);
        String status = (String) statusComboBox.getSelectedItem();

        if (status == null || status.equals("Select Status")) {
            JOptionPane.showMessageDialog(this, "Please select a valid status.", "Status Not Selected", JOptionPane.ERROR_MESSAGE);
            return;
        }

        boolean isUpdated = controller.updateComplaintStatus(complaintId, status);
        if (isUpdated) {
            JOptionPane.showMessageDialog(this, "Complaint status updated successfully!", "Update Successful", JOptionPane.INFORMATION_MESSAGE);
            loadComplaints();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to update complaint status.", "Update Failed", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            String meter = null;
            AdminResolveQueryUI adminPage = new AdminResolveQueryUI(meter);
            adminPage.setVisible(true);
        });
    }
}


       

