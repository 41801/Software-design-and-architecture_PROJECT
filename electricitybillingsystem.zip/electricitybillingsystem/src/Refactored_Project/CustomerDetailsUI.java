package Refactored_Project;

import java.awt.*;
import javax.swing.*;
import java.sql.*;
import net.proteanit.sql.DbUtils;

// R-1: Split responsibilities into CustomerDetailsController for logic and CustomerDetailsUI for UI.
// R-03: Separate concerns into multiple classes (Controller, UI).
public class CustomerDetailsUI extends JFrame {

    private final JTable table;
    private final CustomerDetailsController controller;

    public CustomerDetailsUI(String string) {
        super("Customer Details");

        setSize(1200, 650);
        setLocation(200, 150);
        setLayout(new BorderLayout());

        table = new JTable();  // R-1: Initialize the JTable for displaying data
        controller = new CustomerDetailsController();  // R-1: Create controller to handle logic
        loadCustomerData();  // R-1: Load data from controller

        JScrollPane sp = new JScrollPane(table);  // R-1: Add the table to JScrollPane
        add(sp, BorderLayout.CENTER);  // R-1: Add JScrollPane to JFrame
        setVisible(true);  // R-1: Make the JFrame visible
    }

    // R-1: Method to load customer data using the controller
    private void loadCustomerData() {
       
        ResultSet rs = controller.fetchCustomerData();  // Fetch data through the controller
        try {
            table.setModel(DbUtils.resultSetToTableModel(rs));  // Set data in the table
        } catch (Exception e) {
            e.printStackTrace();  // R-03: Error handling in UI class
        }
    }

    public static void main(String[] args) {
        new CustomerDetailsUI("723979");  // R-1: Launch the CustomerDetailsUI with an initial parameter
    }
}



