package Refactored_Project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class PayBillUI extends JFrame {
    // UI Components
    Choice cmonth;
    JButton pay, back;
    JLabel meternumber, labelname, labelunits, labeltotalbill, labelstatus;

    private String meter;

    public PayBillUI(String meter) {
        this.meter = meter;
        setLayout(null);
        setBounds(300, 150, 900, 600);

        // UI Labels and Buttons
        JLabel heading = new JLabel("Electricity Bill");
        heading.setFont(new Font("Tahoma", Font.BOLD, 24));
        heading.setBounds(120, 5, 400, 30);
        add(heading);

        JLabel lblmeternumber = new JLabel("Meter Number");
        lblmeternumber.setBounds(35, 80, 200, 20);
        add(lblmeternumber);

        meternumber = new JLabel("");
        meternumber.setBounds(300, 80, 200, 20);
        add(meternumber);

        JLabel lblname = new JLabel("Name");
        lblname.setBounds(35, 140, 200, 20);
        add(lblname);

        labelname = new JLabel("");
        labelname.setBounds(300, 140, 200, 20);
        add(labelname);

        JLabel lblmonth = new JLabel("Month");
        lblmonth.setBounds(35, 200, 200, 20);
        add(lblmonth);

        cmonth = new Choice();
        cmonth.setBounds(300, 200, 200, 20);
        addMonthsToChoice();  // Helper function to add months
        add(cmonth);

        JLabel lblunits = new JLabel("Units");
        lblunits.setBounds(35, 260, 200, 20);
        add(lblunits);

        labelunits = new JLabel("");
        labelunits.setBounds(300, 260, 200, 20);
        add(labelunits);

        JLabel lbltotalbill = new JLabel("Total Bill");
        lbltotalbill.setBounds(35, 320, 200, 20);
        add(lbltotalbill);

        labeltotalbill = new JLabel("");
        labeltotalbill.setBounds(300, 320, 200, 20);
        add(labeltotalbill);

        JLabel lblstatus = new JLabel("Status");
        lblstatus.setBounds(35, 380, 200, 20);
        add(lblstatus);

        labelstatus = new JLabel("");
        labelstatus.setBounds(300, 380, 200, 20);
        labelstatus.setForeground(Color.RED);
        add(labelstatus);

        pay = new JButton("Pay");
        pay.setBackground(Color.WHITE);
        pay.setForeground(Color.BLACK);
        pay.setBounds(100, 460, 100, 25);
        add(pay);

        back = new JButton("Back");
        back.setBackground(Color.WHITE);
        back.setForeground(Color.BLACK);
        back.setBounds(230, 460, 100, 25);
        add(back);

        getContentPane().setBackground(Color.WHITE);
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/bill.png"));
        Image i2 = i1.getImage().getScaledInstance(600, 300, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(400, 120, 600, 300);
        add(image);

        // Fetch customer info
        loadCustomerInfo(); // R-1: UI logic in the UI class, should be handled by controller
        loadBillInfo("January"); // Default month, mixing UI logic in the UI class

        // Add Listeners for Buttons
        pay.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateBillStatus(); // R-1 Violation: UI class directly handling business logic
            }
        });

        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false); // UI logic inside action listeners - R-1 violation
            }
        });

        // Update bill info on month change
        cmonth.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                loadBillInfo(cmonth.getSelectedItem()); // R-1 Violation: Mixing UI logic with business logic
            }
        });
    }

    // Method to add months to the Choice dropdown
    private void addMonthsToChoice() {
        cmonth.add("January");
        cmonth.add("February");
        cmonth.add("March");
        cmonth.add("April");
        cmonth.add("May");
        cmonth.add("June");
        cmonth.add("July");
        cmonth.add("August");
        cmonth.add("September");
        cmonth.add("October");
        cmonth.add("November");
        cmonth.add("December");
    }

    // Fetch Customer Information
    void loadCustomerInfo() {
        try (Conn c = new Conn()) {
            ResultSet rs = c.s.executeQuery("SELECT * FROM customer WHERE meter_no = '" + meter + "'");
            if (rs != null && rs.next()) {
                meternumber.setText(meter);
                labelname.setText(rs.getString("name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Fetch Bill Information based on Meter and Month
    void loadBillInfo(String month) {
        try (Conn c = new Conn()) {
            ResultSet rs = c.s.executeQuery("SELECT * FROM bill WHERE meter_no = '" + meter + "' AND month = '" + month + "'");
            if (rs != null && rs.next()) {
                labelunits.setText(rs.getString("units"));
                labeltotalbill.setText(rs.getString("totalbill"));
                labelstatus.setText(rs.getString("status"));
                labelstatus.setForeground("NOT PAID".equals(rs.getString("status")) ? Color.RED : Color.RED); // R-1: UI logic inside class
            }
        } catch (SQLException e) {
            e.printStackTrace(); // R-1 Violation: Exception should be handled more properly
        }
    }

    // Update Bill Status to 'Paid'
    private void updateBillStatus() {
        try (Conn c = new Conn()) {
            c.s.executeUpdate("UPDATE bill SET status = 'Paid' WHERE meter_no = '" + meter + "' AND month = '" + cmonth.getSelectedItem() + "'");
            labelstatus.setText("Payment successful!");
            labelstatus.setForeground(Color.GREEN);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        String meter = "723979";  // Example meter number
        PayBillUI view = new PayBillUI(meter);
        view.setVisible(true);
    }
}




