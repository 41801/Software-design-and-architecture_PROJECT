package Refactored_Project;

public class NewCustomerController {
//R-02  Extracted database logic into a NewCustomerController class for separation of concerns.
    public static boolean addCustomer(String name, String meter, String address, String city, String state, String email, String phone) {
        String query1 = "INSERT INTO customer VALUES (?, ?, ?, ?, ?, ?, ?)";
        String query2 = "INSERT INTO login VALUES (?, '', ?, '', '')";
        try (Conn conn = new Conn()) {
            //R-3 Encapsulated all database queries within CustomerController.
            boolean customerInserted = conn.executeUpdate(query1, name, meter);
            boolean loginInserted = conn.executeUpdate(query2, meter, name);

            return customerInserted && loginInserted;
        }
    }
}
