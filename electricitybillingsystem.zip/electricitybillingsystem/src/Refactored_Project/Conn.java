package Refactored_Project;

import java.sql.*;
import javax.swing.JOptionPane;

public class Conn implements AutoCloseable {
    Connection c;
    Statement s;

    public Conn() {
        try {
            // Replace with your database URL, username, and password
            c = DriverManager.getConnection("jdbc:mysql://localhost:3306/RefactoredProject", "root", "pas41801");
  s = c.createStatement();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Connection getConnection() {
        return c;
    }

    public Statement getStatement() {
        return s;
    }

    @Override
    public void close() {
        try {
            if (s != null) s.close();
            if (c != null) c.close();
        } catch (SQLException ex) {
            ex.printStackTrace();  // Print the stack trace for debugging
            JOptionPane.showMessageDialog(null, "Database error: " + ex.getMessage());
        }
    }

    // Method to execute an update query
    public boolean executeQuery(String query) {
        try (PreparedStatement ps = c.prepareStatement(query);) { // Use the Connection object to prepare the statement
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error executing query: " + e.getMessage());
            return false;
        }
    }

    // Fetch customer details by meter number
    public ResultSet getCustomerDetailsByMeter(String meterNumber) {
        try {
            String query = "SELECT * FROM customer WHERE meter_no = ?";
            PreparedStatement ps = c.prepareStatement(query);
            ps.setString(1, meterNumber);
            return ps.executeQuery();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error fetching customer details: " + e.getMessage());
            return null;
            
        }
        
    }

    PreparedStatement prepareStatement(String query) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    boolean executeUpdate(String query1, String name, String meter) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    

   
}






 



 










