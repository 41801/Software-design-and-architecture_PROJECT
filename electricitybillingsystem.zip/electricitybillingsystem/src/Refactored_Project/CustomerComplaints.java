package Refactored_Project;

import javax.swing.*;
import java.awt.*;
//PROPOSED FEATURE
public class CustomerComplaints extends JFrame {
    private final JTextField nameField;
    private final JTextField meterNumberField;
    private final JTextArea queryField;
    private final CustomerComplaintsController controller;

    public CustomerComplaints(String meterNumber) {
        setTitle("Customer Complaints Panel");
        setSize(500, 350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        controller = new CustomerComplaintsController();
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        // Fields and Labels
        JLabel nameLabel = new JLabel("Customer Name:");
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(nameLabel, gbc);

        nameField = new JTextField(20);
        gbc.gridx = 1; gbc.gridy = 0;
        panel.add(nameField, gbc);

        JLabel meterLabel = new JLabel("Meter Number:");
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(meterLabel, gbc);

        meterNumberField = new JTextField(20);
        meterNumberField.setText(meterNumber);
        gbc.gridx = 1; gbc.gridy = 1;
        panel.add(meterNumberField, gbc);

        JLabel queryLabel = new JLabel("Complaint:");
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(queryLabel, gbc);

        queryField = new JTextArea(5, 20);
        gbc.gridx = 1; gbc.gridy = 2;
        panel.add(new JScrollPane(queryField), gbc);

        JButton submitButton = new JButton("Submit Complaint");
        submitButton.addActionListener(e -> handleSubmit());
        gbc.gridx = 1; gbc.gridy = 3;
        panel.add(submitButton, gbc);

        add(panel);
        setVisible(true);
    }

    private void handleSubmit() {
        String name = nameField.getText();
        String meterNumber = meterNumberField.getText();
        String query = queryField.getText();

        if (name.isEmpty() || meterNumber.isEmpty() || query.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields are required!");
            return;
        }

        if (controller.submitComplaint(name, meterNumber, query)) {
            JOptionPane.showMessageDialog(this, "Complaint submitted successfully!");
            nameField.setText("");
            queryField.setText("");
        } else {
            JOptionPane.showMessageDialog(this, "Failed to submit the complaint. Try again!");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CustomerComplaints(null));
    }
}




