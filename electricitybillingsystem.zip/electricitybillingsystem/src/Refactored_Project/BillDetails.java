package Refactored_Project;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

// R-03: Separated concerns into BillDetails for data operations 

import net.proteanit.sql.DbUtils;

public class BillDetails extends JFrame {
    // R-01: Extracted logic into BillDetails class to segregate responsibilities and make methods concise.
    BillDetails(String meter) {
        
        setSize(700, 650);
        setLocation(400, 150);
        
        getContentPane().setBackground(Color.WHITE);
        
        // Create the table and add it to the frame
        JTable table = createBillDetailsTable(meter);
        
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(0, 0, 700, 650);
        add(sp);
        
        setVisible(true);
    }

    // Helper method to create and populate the table
    private JTable createBillDetailsTable(String meter) {
        JTable table = new JTable();
        try {
            ResultSet rs = UnitConsumedController.getBillDetails(meter);
            if (rs != null) {
                table.setModel(DbUtils.resultSetToTableModel(rs));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return table;
    }

    public static void main(String[] args) {
        new BillDetails("723979"); // Test with meter number
    }
}


